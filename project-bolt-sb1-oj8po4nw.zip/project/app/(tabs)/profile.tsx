import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Switch,
  Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { User, Baby, Settings, Bell, Shield, Heart, Share2, CircleHelp as HelpCircle, ChevronRight, CreditCard as Edit3 } from 'lucide-react-native';

export default function ProfileScreen() {
  const [notifications, setNotifications] = useState(true);
  const [babyName, setBabyName] = useState('Aarav');
  const [babyAge, setBabyAge] = useState('4 months');
  const [motherName, setMotherName] = useState('Priya Sharma');
  const [isEditing, setIsEditing] = useState(false);

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <User size={28} color="#E53E3E" />
          <View>
            <Text style={styles.headerTitle}>Profile</Text>
            <Text style={styles.headerSubtitle}>Manage your account</Text>
          </View>
        </View>
        <TouchableOpacity 
          style={styles.editButton}
          onPress={() => setIsEditing(!isEditing)}
        >
          <Edit3 size={20} color="#E53E3E" />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* User Profile Card */}
        <View style={styles.profileCard}>
          <Image
            source={{ uri: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=400' }}
            style={styles.profileImage}
          />
          <View style={styles.profileInfo}>
            {isEditing ? (
              <TextInput
                style={styles.editInput}
                value={motherName}
                onChangeText={setMotherName}
                placeholder="Enter your name"
              />
            ) : (
              <Text style={styles.userName}>{motherName}</Text>
            )}
            <Text style={styles.userRole}>New Mother</Text>
            <Text style={styles.userLocation}>Delhi, India</Text>
          </View>
        </View>

        {/* Baby Information */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Baby size={20} color="#E53E3E" />
            <Text style={styles.sectionTitle}>Baby Information</Text>
          </View>
          
          <View style={styles.babyCard}>
            <Image
              source={{ uri: 'https://images.pexels.com/photos/1648375/pexels-photo-1648375.jpeg?auto=compress&cs=tinysrgb&w=400' }}
              style={styles.babyImage}
            />
            <View style={styles.babyInfo}>
              {isEditing ? (
                <>
                  <TextInput
                    style={styles.editInput}
                    value={babyName}
                    onChangeText={setBabyName}
                    placeholder="Baby's name"
                  />
                  <TextInput
                    style={styles.editInput}
                    value={babyAge}
                    onChangeText={setBabyAge}
                    placeholder="Baby's age"
                  />
                </>
              ) : (
                <>
                  <Text style={styles.babyName}>{babyName}</Text>
                  <Text style={styles.babyAge}>{babyAge}</Text>
                </>
              )}
              <Text style={styles.babyWeight}>5.2 kg (Normal)</Text>
            </View>
            <View style={styles.babyStats}>
              <View style={styles.statBadge}>
                <Text style={styles.statNumber}>3/5</Text>
                <Text style={styles.statLabel}>Milestones</Text>
              </View>
              <View style={styles.statBadge}>
                <Text style={styles.statNumber}>2/4</Text>
                <Text style={styles.statLabel}>Vaccines</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Settings Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Settings size={20} color="#E53E3E" />
            <Text style={styles.sectionTitle}>Settings</Text>
          </View>
          
          <View style={styles.settingsCard}>
            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Bell size={20} color="#3182CE" />
                <Text style={styles.settingText}>Push Notifications</Text>
              </View>
              <Switch
                value={notifications}
                onValueChange={setNotifications}
                trackColor={{ false: '#CBD5E0', true: '#FED7D7' }}
                thumbColor={notifications ? '#E53E3E' : '#A0AEC0'}
              />
            </View>

            <TouchableOpacity style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Shield size={20} color="#38A169" />
                <Text style={styles.settingText}>Privacy Settings</Text>
              </View>
              <ChevronRight size={20} color="#A0AEC0" />
            </TouchableOpacity>

            <TouchableOpacity style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <HelpCircle size={20} color="#D69E2E" />
                <Text style={styles.settingText}>Help & Support</Text>
              </View>
              <ChevronRight size={20} color="#A0AEC0" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Community Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Heart size={20} color="#E53E3E" />
            <Text style={styles.sectionTitle}>Community</Text>
          </View>
          
          <View style={styles.settingsCard}>
            <TouchableOpacity style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Share2 size={20} color="#805AD5" />
                <Text style={styles.settingText}>Share App with Friends</Text>
              </View>
              <ChevronRight size={20} color="#A0AEC0" />
            </TouchableOpacity>

            <TouchableOpacity style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Heart size={20} color="#E53E3E" />
                <Text style={styles.settingText}>Rate the App</Text>
              </View>
              <ChevronRight size={20} color="#A0AEC0" />
            </TouchableOpacity>
          </View>
        </View>

        {/* App Info */}
        <View style={styles.appInfo}>
          <Text style={styles.appName}>chAIid - Baby Care</Text>
          <Text style={styles.appVersion}>Version 1.0.0</Text>
          <Text style={styles.appDescription}>
            Made with ❤️ for Indian parents during the first 1000 days of their child's life
          </Text>
          
          {/* Built with Bolt Badge */}
          <View style={styles.builtWithBolt}>
            <Text style={styles.boltText}>Built with Bolt</Text>
            <Heart size={12} color="#FF6B6B" fill="#FF6B6B" />
          </View>
        </View>

        {/* Safety Note */}
        <View style={styles.safetyNote}>
          <Shield size={16} color="#D69E2E" />
          <Text style={styles.safetyText}>
            Always consult with qualified healthcare professionals for medical advice. 
            This app provides general information only.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7FAFC',
  },
  header: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#2D3748',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#718096',
  },
  editButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: '#FFF5F5',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  profileCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginTop: 20,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  profileImage: {
    width: 80,
    height: 80,
    borderRadius: 40,
  },
  profileInfo: {
    flex: 1,
    marginLeft: 16,
  },
  userName: {
    fontSize: 20,
    fontWeight: '700',
    color: '#2D3748',
    marginBottom: 4,
  },
  userRole: {
    fontSize: 14,
    color: '#E53E3E',
    fontWeight: '600',
    marginBottom: 2,
  },
  userLocation: {
    fontSize: 12,
    color: '#718096',
  },
  editInput: {
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    fontSize: 16,
    marginBottom: 8,
    backgroundColor: '#F7FAFC',
  },
  section: {
    marginTop: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#2D3748',
  },
  babyCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  babyImage: {
    width: 60,
    height: 60,
    borderRadius: 30,
  },
  babyInfo: {
    flex: 1,
    marginLeft: 12,
  },
  babyName: {
    fontSize: 18,
    fontWeight: '700',
    color: '#2D3748',
    marginBottom: 2,
  },
  babyAge: {
    fontSize: 14,
    color: '#718096',
    marginBottom: 2,
  },
  babyWeight: {
    fontSize: 12,
    color: '#38A169',
    fontWeight: '600',
  },
  babyStats: {
    alignItems: 'center',
    gap: 8,
  },
  statBadge: {
    backgroundColor: '#FFF5F5',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#FED7D7',
  },
  statNumber: {
    fontSize: 14,
    fontWeight: '700',
    color: '#E53E3E',
  },
  statLabel: {
    fontSize: 10,
    color: '#718096',
  },
  settingsCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F7FAFC',
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  settingText: {
    fontSize: 16,
    color: '#2D3748',
    fontWeight: '500',
  },
  appInfo: {
    alignItems: 'center',
    paddingVertical: 30,
  },
  appName: {
    fontSize: 18,
    fontWeight: '700',
    color: '#2D3748',
    marginBottom: 4,
  },
  appVersion: {
    fontSize: 14,
    color: '#718096',
    marginBottom: 8,
  },
  appDescription: {
    fontSize: 14,
    color: '#718096',
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 15,
  },
  builtWithBolt: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF5F5',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    gap: 6,
    borderWidth: 1,
    borderColor: '#FED7D7',
  },
  boltText: {
    fontSize: 12,
    color: '#FF6B6B',
    fontWeight: '600',
  },
  safetyNote: {
    flexDirection: 'row',
    backgroundColor: '#FFFBEB',
    padding: 12,
    borderRadius: 8,
    marginBottom: 30,
    gap: 10,
    borderWidth: 1,
    borderColor: '#FED7AA',
  },
  safetyText: {
    flex: 1,
    fontSize: 12,
    color: '#92400E',
    lineHeight: 16,
  },
});