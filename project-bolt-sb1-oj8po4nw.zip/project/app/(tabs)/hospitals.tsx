import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MapPin, Search, Star, Phone, Navigation, IndianRupee, Clock } from 'lucide-react-native';

interface Hospital {
  id: string;
  name: string;
  nameHindi: string;
  distance: string;
  rating: number;
  specialty: string;
  consultationFee: number;
  deliveryPackage: number;
  address: string;
  phone: string;
  features: string[];
  image: string;
}

const hospitals: Hospital[] = [
  {
    id: '1',
    name: 'Government General Hospital',
    nameHindi: 'सरकारी जनरल अस्पताल',
    distance: '2.3 km',
    rating: 4.1,
    specialty: 'Pediatrics, Maternity',
    consultationFee: 50,
    deliveryPackage: 15000,
    address: 'MG Road, Central Delhi',
    phone: '+91-11-2345-6789',
    features: ['Free for BPL', '24/7 Emergency', 'Vaccination Center'],
    image: 'https://images.pexels.com/photos/263402/pexels-photo-263402.jpeg?auto=compress&cs=tinysrgb&w=400',
  },
  {
    id: '2',
    name: 'Child Care Clinic',
    nameHindi: 'चाइल्ड केयर क्लिनिक',
    distance: '1.8 km',
    rating: 4.5,
    specialty: 'Pediatrics',
    consultationFee: 300,
    deliveryPackage: 0,
    address: 'Lajpat Nagar, New Delhi',
    phone: '+91-11-9876-5432',
    features: ['Child Specialist', 'Vaccination Available', 'Evening Hours'],
    image: 'https://images.pexels.com/photos/40568/medical-appointment-doctor-healthcare-40568.jpeg?auto=compress&cs=tinysrgb&w=400',
  },
  {
    id: '3',
    name: 'Maternity & Child Hospital',
    nameHindi: 'मातृत्व और बाल अस्पताल',
    distance: '3.5 km',
    rating: 4.3,
    specialty: 'Maternity, Neonatal',
    consultationFee: 500,
    deliveryPackage: 35000,
    address: 'Karol Bagh, New Delhi',
    phone: '+91-11-1234-5678',
    features: ['NICU Available', 'Insurance Accepted', 'Cashless Treatment'],
    image: 'https://images.pexels.com/photos/236380/pexels-photo-236380.jpeg?auto=compress&cs=tinysrgb&w=400',
  },
];

export default function HospitalsScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'pediatrics' | 'maternity'>('all');

  const filteredHospitals = hospitals.filter(hospital => {
    const matchesSearch = hospital.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         hospital.nameHindi.includes(searchQuery);
    
    if (selectedFilter === 'all') return matchesSearch;
    if (selectedFilter === 'pediatrics') return matchesSearch && hospital.specialty.includes('Pediatrics');
    if (selectedFilter === 'maternity') return matchesSearch && hospital.specialty.includes('Maternity');
    
    return matchesSearch;
  });

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <MapPin size={28} color="#E53E3E" />
          <View>
            <Text style={styles.headerTitle}>Nearby Hospitals</Text>
            <Text style={styles.headerSubtitle}>Find affordable healthcare</Text>
          </View>
        </View>
      </View>

      {/* Search */}
      <View style={styles.searchContainer}>
        <View style={styles.searchBox}>
          <Search size={20} color="#718096" />
          <TextInput
            style={styles.searchInput}
            placeholder="Search hospitals..."
            placeholderTextColor="#A0AEC0"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
      </View>

      {/* Filters */}
      <View style={styles.filterContainer}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <TouchableOpacity
            style={[styles.filterButton, selectedFilter === 'all' && styles.activeFilter]}
            onPress={() => setSelectedFilter('all')}
          >
            <Text style={[styles.filterText, selectedFilter === 'all' && styles.activeFilterText]}>
              All Hospitals
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.filterButton, selectedFilter === 'pediatrics' && styles.activeFilter]}
            onPress={() => setSelectedFilter('pediatrics')}
          >
            <Text style={[styles.filterText, selectedFilter === 'pediatrics' && styles.activeFilterText]}>
              Child Care
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.filterButton, selectedFilter === 'maternity' && styles.activeFilter]}
            onPress={() => setSelectedFilter('maternity')}
          >
            <Text style={[styles.filterText, selectedFilter === 'maternity' && styles.activeFilterText]}>
              Maternity
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </View>

      {/* Hospital List */}
      <ScrollView style={styles.hospitalList} showsVerticalScrollIndicator={false}>
        {filteredHospitals.map((hospital) => (
          <View key={hospital.id} style={styles.hospitalCard}>
            {/* Hospital Image */}
            <Image source={{ uri: hospital.image }} style={styles.hospitalImage} />
            
            {/* Hospital Info */}
            <View style={styles.hospitalContent}>
              <View style={styles.hospitalHeader}>
                <View style={styles.hospitalInfo}>
                  <Text style={styles.hospitalName}>{hospital.name}</Text>
                  <Text style={styles.hospitalNameHindi}>{hospital.nameHindi}</Text>
                  <Text style={styles.hospitalSpecialty}>{hospital.specialty}</Text>
                </View>
                <View style={styles.hospitalMeta}>
                  <View style={styles.rating}>
                    <Star size={16} color="#D69E2E" fill="#D69E2E" />
                    <Text style={styles.ratingText}>{hospital.rating}</Text>
                  </View>
                  <Text style={styles.distance}>{hospital.distance}</Text>
                </View>
              </View>

              {/* Pricing */}
              <View style={styles.pricingContainer}>
                <View style={styles.priceItem}>
                  <IndianRupee size={16} color="#38A169" />
                  <View>
                    <Text style={styles.priceLabel}>Consultation</Text>
                    <Text style={styles.priceValue}>₹{hospital.consultationFee}</Text>
                  </View>
                </View>
                {hospital.deliveryPackage > 0 && (
                  <View style={styles.priceItem}>
                    <IndianRupee size={16} color="#D69E2E" />
                    <View>
                      <Text style={styles.priceLabel}>Delivery Package</Text>
                      <Text style={styles.priceValue}>₹{hospital.deliveryPackage.toLocaleString()}</Text>
                    </View>
                  </View>
                )}
              </View>

              {/* Features */}
              <View style={styles.featuresContainer}>
                {hospital.features.map((feature, index) => (
                  <View key={index} style={styles.featureTag}>
                    <Text style={styles.featureText}>{feature}</Text>
                  </View>
                ))}
              </View>

              {/* Actions */}
              <View style={styles.actionsContainer}>
                <TouchableOpacity style={styles.actionButton}>
                  <Phone size={18} color="#E53E3E" />
                  <Text style={styles.actionText}>Call</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.actionButton}>
                  <Navigation size={18} color="#E53E3E" />
                  <Text style={styles.actionText}>Directions</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.actionButton}>
                  <Clock size={18} color="#E53E3E" />
                  <Text style={styles.actionText}>Hours</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7FAFC',
  },
  header: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#2D3748',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#718096',
  },
  searchContainer: {
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F7FAFC',
    borderRadius: 12,
    paddingHorizontal: 15,
    paddingVertical: 12,
    gap: 10,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#2D3748',
  },
  filterContainer: {
    paddingVertical: 15,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  filterButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#EDF2F7',
    marginLeft: 15,
    marginRight: 5,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  activeFilter: {
    backgroundColor: '#E53E3E',
    borderColor: '#E53E3E',
  },
  filterText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#718096',
  },
  activeFilterText: {
    color: '#FFFFFF',
  },
  hospitalList: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 15,
  },
  hospitalCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    overflow: 'hidden',
  },
  hospitalImage: {
    width: '100%',
    height: 120,
    resizeMode: 'cover',
  },
  hospitalContent: {
    padding: 16,
  },
  hospitalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  hospitalInfo: {
    flex: 1,
  },
  hospitalName: {
    fontSize: 16,
    fontWeight: '700',
    color: '#2D3748',
    marginBottom: 2,
  },
  hospitalNameHindi: {
    fontSize: 14,
    color: '#718096',
    marginBottom: 4,
  },
  hospitalSpecialty: {
    fontSize: 14,
    color: '#E53E3E',
    fontWeight: '600',
  },
  hospitalMeta: {
    alignItems: 'flex-end',
  },
  rating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginBottom: 4,
  },
  ratingText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#2D3748',
  },
  distance: {
    fontSize: 12,
    color: '#718096',
  },
  pricingContainer: {
    flexDirection: 'row',
    gap: 20,
    marginBottom: 12,
  },
  priceItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  priceLabel: {
    fontSize: 12,
    color: '#718096',
  },
  priceValue: {
    fontSize: 14,
    fontWeight: '700',
    color: '#2D3748',
  },
  featuresContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 12,
  },
  featureTag: {
    backgroundColor: '#FFF5F5',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#FED7D7',
  },
  featureText: {
    fontSize: 11,
    color: '#E53E3E',
    fontWeight: '600',
  },
  actionsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#EDF2F7',
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  actionText: {
    fontSize: 14,
    color: '#E53E3E',
    fontWeight: '600',
  },
});