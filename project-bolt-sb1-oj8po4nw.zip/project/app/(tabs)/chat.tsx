import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Send, Bot, User } from 'lucide-react-native';

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
}

const commonQuestions = [
  "My baby is crying a lot, what should I do?",
  "मेरा बच्चा दूध नहीं पी रहा",
  "When should I start solid food?",
  "बच्चे का वजन कम है",
  "Baby not sleeping at night",
  "टीकाकरण कब कराना चाहिए?",
];

const aiResponses: { [key: string]: string } = {
  "crying": "बच्चे का रोना सामान्य है। Check if baby is hungry, needs diaper change, or wants comfort. Try gentle rocking, soft singing, or skin-to-skin contact. If crying continues for hours without reason, consult a doctor.",
  "milk": "दूध न पीना चिंता की बात है। Check if baby is latching properly. Try different feeding positions. Ensure you're relaxed while feeding. If problem persists, consult pediatrician immediately.",
  "food": "6 महीने के बाद solid food शुरू करें। Begin with mashed banana, rice cereal, or dal ka paani. One new food at a time, 3-4 days तक try करें। Baby's digestive system needs time to adjust.",
  "weight": "Weight gain की चिंता natural है। 0-6 months में 150-200g per week gain normal है। Regular checkups कराएं। Breastfeeding frequency बढ़ाएं। Doctor से growth chart discuss करें।",
  "sleep": "नींद की समस्या common है। Create bedtime routine. Room को dark और quiet रखें। Day में enough feeding ensure करें। Swaddling try करें। Patience रखें, patterns develop होते हैं।",
  "vaccination": "Vaccination schedule बहुत important है। Birth से 2 years तक regular vaccines जरूरी हैं। Government hospitals में free vaccines मिलते हैं। Missed vaccines के लिए doctor से consult करें।",
  "default": "I understand your concern about your baby. हर parent को ये doubts होते हैं। For specific medical advice, please consult your pediatrician. आप हमारे Hospital tab से nearby doctors find कर सकते हैं।"
};

export default function ChatScreen() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'नमस्ते! I am your AI parenting assistant. आप कोई भी baby care question पूछ सकते हैं। How can I help you today?',
      isUser: false,
      timestamp: new Date(),
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollViewRef = useRef<ScrollView>(null);

  const generateResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes('cry') || lowerMessage.includes('रो')) {
      return aiResponses.crying;
    } else if (lowerMessage.includes('milk') || lowerMessage.includes('दूध') || lowerMessage.includes('feed')) {
      return aiResponses.milk;
    } else if (lowerMessage.includes('food') || lowerMessage.includes('खाना') || lowerMessage.includes('solid')) {
      return aiResponses.food;
    } else if (lowerMessage.includes('weight') || lowerMessage.includes('वजन')) {
      return aiResponses.weight;
    } else if (lowerMessage.includes('sleep') || lowerMessage.includes('नींद')) {
      return aiResponses.sleep;
    } else if (lowerMessage.includes('vaccin') || lowerMessage.includes('टीका')) {
      return aiResponses.vaccination;
    } else {
      return aiResponses.default;
    }
  };

  const sendMessage = () => {
    if (inputText.trim() === '') return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText,
      isUser: true,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: generateResponse(inputText),
        isUser: false,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const sendQuickQuestion = (question: string) => {
    setInputText(question);
  };

  useEffect(() => {
    scrollViewRef.current?.scrollToEnd({ animated: true });
  }, [messages, isTyping]);

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView 
        style={styles.container} 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerContent}>
            <Bot size={28} color="#E53E3E" />
            <View>
              <Text style={styles.headerTitle}>AI Assistant</Text>
              <Text style={styles.headerSubtitle}>Your parenting helper</Text>
            </View>
          </View>
        </View>

        {/* Quick Questions */}
        <View style={styles.quickQuestions}>
          <Text style={styles.quickQuestionsTitle}>Common Questions:</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {commonQuestions.map((question, index) => (
              <TouchableOpacity
                key={index}
                style={styles.quickQuestionButton}
                onPress={() => sendQuickQuestion(question)}
              >
                <Text style={styles.quickQuestionText}>{question}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Messages */}
        <ScrollView 
          ref={scrollViewRef}
          style={styles.messagesContainer}
          showsVerticalScrollIndicator={false}
        >
          {messages.map((message) => (
            <View
              key={message.id}
              style={[
                styles.messageContainer,
                message.isUser ? styles.userMessage : styles.aiMessage,
              ]}
            >
              {!message.isUser && (
                <View style={styles.aiAvatar}>
                  <Bot size={16} color="#E53E3E" />
                </View>
              )}
              <View
                style={[
                  styles.messageBubble,
                  message.isUser ? styles.userBubble : styles.aiBubble,
                ]}
              >
                <Text
                  style={[
                    styles.messageText,
                    message.isUser ? styles.userText : styles.aiText,
                  ]}
                >
                  {message.text}
                </Text>
              </View>
              {message.isUser && (
                <View style={styles.userAvatar}>
                  <User size={16} color="#FFFFFF" />
                </View>
              )}
            </View>
          ))}
          
          {isTyping && (
            <View style={[styles.messageContainer, styles.aiMessage]}>
              <View style={styles.aiAvatar}>
                <Bot size={16} color="#E53E3E" />
              </View>
              <View style={[styles.messageBubble, styles.aiBubble]}>
                <Text style={styles.typingText}>AI is typing...</Text>
              </View>
            </View>
          )}
        </ScrollView>

        {/* Input */}
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.textInput}
            value={inputText}
            onChangeText={setInputText}
            placeholder="Type your question in Hindi or English..."
            placeholderTextColor="#A0AEC0"
            multiline
            onSubmitEditing={sendMessage}
          />
          <TouchableOpacity
            style={[
              styles.sendButton,
              inputText.trim() ? styles.sendButtonActive : {},
            ]}
            onPress={sendMessage}
            disabled={!inputText.trim()}
          >
            <Send size={20} color={inputText.trim() ? '#FFFFFF' : '#A0AEC0'} />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7FAFC',
  },
  header: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#2D3748',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#718096',
  },
  quickQuestions: {
    backgroundColor: '#FFFFFF',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  quickQuestionsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#4A5568',
    marginBottom: 10,
    paddingHorizontal: 20,
  },
  quickQuestionButton: {
    backgroundColor: '#FFF5F5',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginLeft: 10,
    marginRight: 5,
    borderWidth: 1,
    borderColor: '#FED7D7',
  },
  quickQuestionText: {
    fontSize: 12,
    color: '#E53E3E',
    fontWeight: '500',
  },
  messagesContainer: {
    flex: 1,
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  messageContainer: {
    flexDirection: 'row',
    marginVertical: 5,
    alignItems: 'flex-end',
  },
  userMessage: {
    justifyContent: 'flex-end',
  },
  aiMessage: {
    justifyContent: 'flex-start',
  },
  aiAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#FFF5F5',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
    borderWidth: 1,
    borderColor: '#FED7D7',
  },
  userAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#E53E3E',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 10,
  },
  messageBubble: {
    maxWidth: '75%',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 20,
  },
  userBubble: {
    backgroundColor: '#E53E3E',
    borderBottomRightRadius: 4,
  },
  aiBubble: {
    backgroundColor: '#FFFFFF',
    borderBottomLeftRadius: 4,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  messageText: {
    fontSize: 15,
    lineHeight: 22,
  },
  userText: {
    color: '#FFFFFF',
  },
  aiText: {
    color: '#2D3748',
  },
  typingText: {
    color: '#718096',
    fontStyle: 'italic',
  },
  inputContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#E2E8F0',
    gap: 10,
  },
  textInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 25,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 15,
    maxHeight: 100,
    backgroundColor: '#F7FAFC',
  },
  sendButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#EDF2F7',
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendButtonActive: {
    backgroundColor: '#E53E3E',
  },
});