import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { TrendingUp, Calendar, Syringe, CircleCheck as CheckCircle, CircleAlert as AlertCircle, Baby } from 'lucide-react-native';

interface Milestone {
  age: string;
  title: string;
  description: string;
  completed: boolean;
}

interface Vaccine {
  age: string;
  name: string;
  nameHindi: string;
  dueDate: string;
  completed: boolean;
  important: boolean;
}

const milestones: Milestone[] = [
  {
    age: '0-1 month',
    title: 'First Smile',
    description: 'Social smile, follows objects with eyes',
    completed: true,
  },
  {
    age: '2-3 months',
    title: 'Head Control',
    description: 'Holds head up, responds to sounds',
    completed: true,
  },
  {
    age: '4-6 months',
    title: 'Rolling Over',
    description: 'Rolls from tummy to back, sits with support',
    completed: false,
  },
  {
    age: '6-9 months',
    title: 'Sitting Up',
    description: 'Sits without support, babbles',
    completed: false,
  },
  {
    age: '9-12 months',
    title: 'Crawling & Standing',
    description: 'Crawls, pulls to stand, first words',
    completed: false,
  },
];

const vaccines: Vaccine[] = [
  {
    age: 'Birth',
    name: 'BCG + OPV 0',
    nameHindi: 'बीसीजी + ओपीवी',
    dueDate: 'At birth',
    completed: true,
    important: true,
  },
  {
    age: '6 weeks',
    name: 'DPT 1 + OPV 1 + Hep B 1',
    nameHindi: 'डीपीटी + ओपीवी + हेप बी',
    dueDate: '15 March 2024',
    completed: true,
    important: true,
  },
  {
    age: '10 weeks',
    name: 'DPT 2 + OPV 2 + Hep B 2',
    nameHindi: 'डीपीटी + ओपीवी + हेप बी',
    dueDate: '12 April 2024',
    completed: false,
    important: true,
  },
  {
    age: '14 weeks',
    name: 'DPT 3 + OPV 3 + Hep B 3',
    nameHindi: 'डीपीटी + ओपीवी + हेप बी',
    dueDate: '10 May 2024',
    completed: false,
    important: true,
  },
];

export default function GrowthScreen() {
  const [activeTab, setActiveTab] = useState<'milestones' | 'vaccines'>('milestones');

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <TrendingUp size={28} color="#E53E3E" />
          <View>
            <Text style={styles.headerTitle}>Growth Tracker</Text>
            <Text style={styles.headerSubtitle}>Monitor your baby's development</Text>
          </View>
        </View>
      </View>

      {/* Baby Info Card */}
      <View style={styles.babyInfoCard}>
        <Image
          source={{ uri: 'https://images.pexels.com/photos/1648375/pexels-photo-1648375.jpeg?auto=compress&cs=tinysrgb&w=400' }}
          style={styles.babyImage}
        />
        <View style={styles.babyInfo}>
          <Text style={styles.babyName}>Aarav</Text>
          <Text style={styles.babyAge}>4 months old</Text>
          <Text style={styles.babyWeight}>5.2 kg (Normal)</Text>
        </View>
        <View style={styles.babyStats}>
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>3/5</Text>
            <Text style={styles.statLabel}>Milestones</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>2/4</Text>
            <Text style={styles.statLabel}>Vaccines</Text>
          </View>
        </View>
      </View>

      {/* Tab Navigation */}
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'milestones' && styles.activeTab]}
          onPress={() => setActiveTab('milestones')}
        >
          <Baby size={20} color={activeTab === 'milestones' ? '#FFFFFF' : '#718096'} />
          <Text style={[styles.tabText, activeTab === 'milestones' && styles.activeTabText]}>
            Milestones
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'vaccines' && styles.activeTab]}
          onPress={() => setActiveTab('vaccines')}
        >
          <Syringe size={20} color={activeTab === 'vaccines' ? '#FFFFFF' : '#718096'} />
          <Text style={[styles.tabText, activeTab === 'vaccines' && styles.activeTabText]}>
            Vaccines
          </Text>
        </TouchableOpacity>
      </View>

      {/* Content */}
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {activeTab === 'milestones' ? (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Development Milestones</Text>
            <Text style={styles.sectionSubtitle}>
              Track your baby's important developmental stages
            </Text>
            
            {milestones.map((milestone, index) => (
              <View key={index} style={styles.milestoneCard}>
                <View style={styles.milestoneHeader}>
                  <View style={styles.milestoneAge}>
                    <Text style={styles.milestoneAgeText}>{milestone.age}</Text>
                  </View>
                  <View style={styles.milestoneIcon}>
                    {milestone.completed ? (
                      <CheckCircle size={24} color="#38A169" />
                    ) : (
                      <View style={styles.uncheckedCircle} />
                    )}
                  </View>
                </View>
                <Text style={styles.milestoneTitle}>{milestone.title}</Text>
                <Text style={styles.milestoneDescription}>{milestone.description}</Text>
                {milestone.completed && (
                  <Text style={styles.completedText}>✓ Achieved</Text>
                )}
              </View>
            ))}
          </View>
        ) : (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Vaccination Schedule</Text>
            <Text style={styles.sectionSubtitle}>
              Indian Academy of Pediatrics recommended schedule
            </Text>
            
            {vaccines.map((vaccine, index) => (
              <View
                key={index}
                style={[
                  styles.vaccineCard,
                  vaccine.completed && styles.completedVaccineCard,
                ]}
              >
                <View style={styles.vaccineHeader}>
                  <View style={styles.vaccineAge}>
                    <Text style={styles.vaccineAgeText}>{vaccine.age}</Text>
                  </View>
                  <View style={styles.vaccineStatus}>
                    {vaccine.completed ? (
                      <CheckCircle size={20} color="#38A169" />
                    ) : vaccine.important ? (
                      <AlertCircle size={20} color="#D69E2E" />
                    ) : (
                      <Syringe size={20} color="#718096" />
                    )}
                  </View>
                </View>
                
                <Text style={styles.vaccineName}>{vaccine.name}</Text>
                <Text style={styles.vaccineNameHindi}>{vaccine.nameHindi}</Text>
                
                {!vaccine.completed && (
                  <View style={styles.vaccineDue}>
                    <Calendar size={16} color="#D69E2E" />
                    <Text style={styles.vaccineDueText}>Due: {vaccine.dueDate}</Text>
                  </View>
                )}
                
                {vaccine.completed && (
                  <Text style={styles.vaccineCompleted}>✓ Completed</Text>
                )}
              </View>
            ))}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7FAFC',
  },
  header: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#2D3748',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#718096',
  },
  babyInfoCard: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    marginTop: 15,
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  babyImage: {
    width: 60,
    height: 60,
    borderRadius: 30,
  },
  babyInfo: {
    flex: 1,
    marginLeft: 15,
  },
  babyName: {
    fontSize: 18,
    fontWeight: '700',
    color: '#2D3748',
  },
  babyAge: {
    fontSize: 14,
    color: '#718096',
    marginTop: 2,
  },
  babyWeight: {
    fontSize: 12,
    color: '#38A169',
    marginTop: 2,
    fontWeight: '600',
  },
  babyStats: {
    alignItems: 'center',
  },
  statItem: {
    alignItems: 'center',
    marginBottom: 8,
  },
  statNumber: {
    fontSize: 16,
    fontWeight: '700',
    color: '#E53E3E',
  },
  statLabel: {
    fontSize: 10,
    color: '#718096',
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    marginTop: 15,
    borderRadius: 12,
    padding: 4,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 8,
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
  },
  activeTab: {
    backgroundColor: '#E53E3E',
  },
  tabText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#718096',
  },
  activeTabText: {
    color: '#FFFFFF',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 15,
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#2D3748',
    marginBottom: 5,
  },
  sectionSubtitle: {
    fontSize: 14,
    color: '#718096',
    marginBottom: 20,
  },
  milestoneCard: {
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  milestoneHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  milestoneAge: {
    backgroundColor: '#FFF5F5',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#FED7D7',
  },
  milestoneAgeText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#E53E3E',
  },
  milestoneIcon: {
    width: 24,
    height: 24,
  },
  uncheckedCircle: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#CBD5E0',
  },
  milestoneTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#2D3748',
    marginBottom: 4,
  },
  milestoneDescription: {
    fontSize: 14,
    color: '#718096',
    lineHeight: 20,
  },
  completedText: {
    fontSize: 12,
    color: '#38A169',
    fontWeight: '600',
    marginTop: 8,
  },
  vaccineCard: {
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  completedVaccineCard: {
    backgroundColor: '#F0FFF4',
    borderColor: '#9AE6B4',
  },
  vaccineHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  vaccineAge: {
    backgroundColor: '#FFFBEB',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#FED7AA',
  },
  vaccineAgeText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#D69E2E',
  },
  vaccineStatus: {
    width: 20,
    height: 20,
  },
  vaccineName: {
    fontSize: 16,
    fontWeight: '700',
    color: '#2D3748',
    marginBottom: 2,
  },
  vaccineNameHindi: {
    fontSize: 14,
    color: '#718096',
    marginBottom: 8,
  },
  vaccineDue: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  vaccineDueText: {
    fontSize: 12,
    color: '#D69E2E',
    fontWeight: '600',
  },
  vaccineCompleted: {
    fontSize: 12,
    color: '#38A169',
    fontWeight: '600',
  },
});