import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { 
  MessageCircle, 
  TrendingUp, 
  MapPin, 
  Phone, 
  Heart,
  Baby,
  Shield,
  Clock
} from 'lucide-react-native';

const { width } = Dimensions.get('window');

export default function HomeScreen() {
  const navigateToChat = () => {
    router.push('/(tabs)/chat');
  };

  const navigateToGrowth = () => {
    router.push('/(tabs)/growth');
  };

  const navigateToHospitals = () => {
    router.push('/(tabs)/hospitals');
  };

  const handleEmergencyCall = () => {
    // In a real app, this would initiate an emergency call
    console.log('Emergency call initiated');
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerContent}>
            <View style={styles.logoContainer}>
              <Baby size={32} color="#E53E3E" />
              <View>
                <Text style={styles.appName}>chAIid</Text>
                <Text style={styles.tagline}>Baby Care for Indian Parents</Text>
              </View>
            </View>
            <View style={styles.emergencyButton}>
              <TouchableOpacity 
                style={styles.emergencyIcon}
                onPress={handleEmergencyCall}
              >
                <Phone size={20} color="#FFFFFF" />
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* Hero Section */}
        <View style={styles.heroSection}>
          <Image
            source={{ uri: 'https://images.pexels.com/photos/1257110/pexels-photo-1257110.jpeg?auto=compress&cs=tinysrgb&w=800' }}
            style={styles.heroImage}
          />
          <View style={styles.heroOverlay}>
            <Text style={styles.heroTitle}>
              First 1000 Days Matter
            </Text>
            <Text style={styles.heroSubtitle}>
              Expert guidance for your baby's crucial early development
            </Text>
          </View>
        </View>

        {/* Quick Stats */}
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Shield size={24} color="#38A169" />
            <Text style={styles.statNumber}>24/7</Text>
            <Text style={styles.statLabel}>AI Support</Text>
          </View>
          <View style={styles.statCard}>
            <Heart size={24} color="#E53E3E" />
            <Text style={styles.statNumber}>1000+</Text>
            <Text style={styles.statLabel}>Parents Helped</Text>
          </View>
          <View style={styles.statCard}>
            <Clock size={24} color="#3182CE" />
            <Text style={styles.statNumber}>Free</Text>
            <Text style={styles.statLabel}>Always</Text>
          </View>
        </View>

        {/* Main Features */}
        <View style={styles.featuresContainer}>
          <Text style={styles.sectionTitle}>How can we help you today?</Text>
          
          <TouchableOpacity 
            style={[styles.featureCard, styles.primaryFeature]}
            onPress={navigateToChat}
          >
            <View style={styles.featureIcon}>
              <MessageCircle size={32} color="#FFFFFF" />
            </View>
            <View style={styles.featureContent}>
              <Text style={styles.featureTitle}>AI Chatbot</Text>
              <Text style={styles.featureSubtitle}>
                Ask questions about feeding, sleep, development in Hindi or English
              </Text>
              <Text style={styles.featureHint}>
                "मेरा बच्चा रो रहा है" • "Baby not eating well"
              </Text>
            </View>
          </TouchableOpacity>

          <View style={styles.featureRow}>
            <TouchableOpacity 
              style={[styles.featureCard, styles.secondaryFeature]}
              onPress={navigateToGrowth}
            >
              <View style={styles.featureIcon}>
                <TrendingUp size={28} color="#FFFFFF" />
              </View>
              <View style={styles.featureContent}>
                <Text style={styles.featureTitle}>Growth Tracker</Text>
                <Text style={styles.featureSubtitle}>
                  Monitor milestones & vaccination schedule
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity 
              style={[styles.featureCard, styles.secondaryFeature]}
              onPress={navigateToHospitals}
            >
              <View style={styles.featureIcon}>
                <MapPin size={28} color="#FFFFFF" />
              </View>
              <View style={styles.featureContent}>
                <Text style={styles.featureTitle}>Find Hospitals</Text>
                <Text style={styles.featureSubtitle}>
                  Nearby affordable healthcare options
                </Text>
              </View>
            </TouchableOpacity>
          </View>

          <TouchableOpacity 
            style={[styles.featureCard, styles.emergencyFeature]}
            onPress={handleEmergencyCall}
          >
            <View style={styles.featureIcon}>
              <Phone size={32} color="#FFFFFF" />
            </View>
            <View style={styles.featureContent}>
              <Text style={styles.featureTitle}>Emergency Help</Text>
              <Text style={styles.featureSubtitle}>
                Immediate assistance for urgent situations
              </Text>
              <Text style={styles.emergencyNumber}>
                Call: 102 (Ambulance) • 1098 (Child Helpline)
              </Text>
            </View>
          </TouchableOpacity>
        </View>

        {/* Tips Section */}
        <View style={styles.tipsSection}>
          <Text style={styles.sectionTitle}>Today's Parenting Tip</Text>
          <View style={styles.tipCard}>
            <Image
              source={{ uri: 'https://images.pexels.com/photos/1648375/pexels-photo-1648375.jpeg?auto=compress&cs=tinysrgb&w=400' }}
              style={styles.tipImage}
            />
            <View style={styles.tipContent}>
              <Text style={styles.tipTitle}>Skin-to-Skin Contact</Text>
              <Text style={styles.tipText}>
                Regular skin-to-skin contact helps regulate baby's temperature, heart rate, and promotes bonding. Try for at least 1 hour daily.
              </Text>
            </View>
          </View>
        </View>

        {/* Built with Bolt Badge */}
        <View style={styles.boltBadge}>
          <Text style={styles.boltText}>Built with Bolt</Text>
          <Heart size={16} color="#FF6B6B" fill="#FF6B6B" />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7FAFC',
  },
  header: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  logoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  appName: {
    fontSize: 24,
    fontWeight: '700',
    color: '#E53E3E',
  },
  tagline: {
    fontSize: 12,
    color: '#718096',
    fontWeight: '500',
  },
  emergencyButton: {
    alignItems: 'center',
  },
  emergencyIcon: {
    backgroundColor: '#E53E3E',
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },
  heroSection: {
    position: 'relative',
    height: 200,
    marginHorizontal: 20,
    marginTop: 20,
    borderRadius: 16,
    overflow: 'hidden',
  },
  heroImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  heroOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    padding: 20,
  },
  heroTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  heroSubtitle: {
    fontSize: 14,
    color: '#FFFFFF',
    opacity: 0.9,
    lineHeight: 20,
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 20,
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  statNumber: {
    fontSize: 20,
    fontWeight: '700',
    color: '#2D3748',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#718096',
    textAlign: 'center',
    marginTop: 2,
  },
  featuresContainer: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#2D3748',
    marginBottom: 16,
  },
  featureCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  primaryFeature: {
    backgroundColor: '#E53E3E',
    borderColor: '#E53E3E',
  },
  secondaryFeature: {
    backgroundColor: '#3182CE',
    borderColor: '#3182CE',
    flex: 1,
  },
  emergencyFeature: {
    backgroundColor: '#D69E2E',
    borderColor: '#D69E2E',
  },
  featureRow: {
    flexDirection: 'row',
    gap: 12,
  },
  featureIcon: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  featureContent: {
    flex: 1,
  },
  featureTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  featureSubtitle: {
    fontSize: 14,
    color: '#FFFFFF',
    opacity: 0.9,
    lineHeight: 20,
  },
  featureHint: {
    fontSize: 12,
    color: '#FFFFFF',
    opacity: 0.8,
    marginTop: 8,
    fontStyle: 'italic',
  },
  emergencyNumber: {
    fontSize: 12,
    color: '#FFFFFF',
    opacity: 0.9,
    marginTop: 8,
    fontWeight: '600',
  },
  tipsSection: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  tipCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  tipImage: {
    width: '100%',
    height: 120,
    resizeMode: 'cover',
  },
  tipContent: {
    padding: 16,
  },
  tipTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#2D3748',
    marginBottom: 8,
  },
  tipText: {
    fontSize: 14,
    color: '#4A5568',
    lineHeight: 20,
  },
  boltBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFF5F5',
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginHorizontal: 20,
    marginBottom: 20,
    borderRadius: 12,
    gap: 8,
    borderWidth: 1,
    borderColor: '#FED7D7',
  },
  boltText: {
    fontSize: 14,
    color: '#FF6B6B',
    fontWeight: '600',
  },
});